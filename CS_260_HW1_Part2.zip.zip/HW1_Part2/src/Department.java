
//When coding in an interface you will not use curly brackets you end everything in a semi-colon
//When coding in a normal class use the curly braces.



public interface Department {
    void printDepartmentName();
}
